# COCOVANTA V19 — Strategic Buyer Experience & Payment Clarity

## Fokus rilis
COCOVANTA tetap merupakan Indonesian Commodity Trader & Exporter. Rilis ini memperdalam pengalaman pembeli, informasi produk berbasis bukti, dan transparansi tahapan pembayaran. Website tetap berupa frontend statis untuk GitHub Pages.

## Fitur baru
- `product-intelligence.html`: kerangka Product Intelligence dan konsep Digital Product Passport berbasis bukti lot.
- `payment-terms.html`: penjelasan pembayaran standar yang diusulkan, 50% uang muka setelah PI/kontrak disetujui dan 50% pelunasan sebelum shipment.
- Penautan halaman Payment Terms dan Product Intelligence dari navigasi/tautan internal yang relevan.
- Sitemap diperbarui.
- Trade Tools publik diarahkan ke kebutuhan buyer; teaser kalkulator margin internal dan checklist kesiapan supplier tidak lagi dipromosikan sebagai alat publik.

## Ketentuan pembayaran yang dijelaskan
1. 50% advance payment setelah buyer menerima/menyetujui Proforma Invoice atau kontrak penjualan.
2. Eksekusi order dimulai setelah dana uang muka diterima/cleared dan persyaratan awal dipenuhi.
3. 50% balance payment dibayarkan sebelum barang dikapalkan/dikirim sesuai milestone pra-pengapalan yang disepakati.
4. Shipment dilakukan setelah pelunasan diterima dan persyaratan pra-pengapalan terpenuhi.
5. Detail final (mata uang, rekening penerima, biaya bank, inspeksi, tenggat, Incoterm dan pengecualian) wajib tertulis di PI/kontrak. Jika dokumen transaksi menyatakan ketentuan berbeda yang disepakati, dokumen transaksi itulah yang berlaku.

## Batasan dan kejujuran fitur
- Halaman pembayaran adalah penjelasan komersial, bukan invoice atau instruksi transfer.
- Tidak ada gateway pembayaran, escrow, verifikasi transfer otomatis, CRM, database, live inventory atau portal pelanggan.
- Product Passport adalah kerangka/templat dokumentasi. Tidak diklaim sebagai blockchain, sertifikasi, tanda tangan digital atau verifikasi independen.
- Informasi supplier dan sumber jaringan tetap privat; tidak ada direktori supplier publik atau penghubung buyer langsung ke supplier.
- Form RFQ tetap menggunakan alur WhatsApp/browser yang sudah dijelaskan pada README.

## Hosting
Siap dipublikasikan sebagai website statis GitHub Pages. Belum diunggah atau dipublikasikan ke akun GitHub/domain produksi.
