# Panduan Publikasi GitHub Pages — COCOVANTA V18

Website ini merupakan frontend statis. Unggah isi folder ke root repository GitHub, lalu aktifkan Settings → Pages → Deploy from a branch → `main` → `/ (root)`. Tetapkan custom domain `cocovanta.web.id` pada Pages. Ikuti DNS record yang ditampilkan GitHub secara persis; jangan mencampur DNS dari layanan hosting lama. Aktifkan HTTPS setelah verifikasi domain selesai.

Form RFQ dan supplier hanya menyiapkan pesan WhatsApp. Pengunjung tetap harus menekan tombol Send di WhatsApp. GitHub Pages tidak menjalankan API, database, CRM, atau fungsi server. Untuk penerimaan RFQ otomatis, dibutuhkan backend terpisah yang aman.
