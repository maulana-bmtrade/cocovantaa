/* Supplier introduction handoff for the static public website. */
(() => {
 const form = document.querySelector('#supplier-introduction-form');
 if (!form) return;
 const button = form.querySelector('button[type="submit"]');
 const status = document.createElement('p');
 status.className = 'text-xs mt-2'; status.setAttribute('role','status'); form.append(status);
 form.addEventListener('submit', event => {
   event.preventDefault(); if (!form.reportValidity()) return;
   const data = Object.fromEntries(new FormData(form).entries());
   const labels = {
     company_name:'Company / producer', contact_person:'Contact person', email:'Business email', phone:'Phone / WhatsApp',
     location:'Production location', business_role:'Business role', product:'Product / commodity', capacity:'Available capacity',
     minimum_order:'Minimum order', specifications:'Grades / specifications / evidence',
     documents_export_experience:'Documents / export experience', message:'Additional information'
   };
   const lines = ['COCOVANTA — PRIVATE SUPPLIER INTRODUCTION',''];
   for (const [key,label] of Object.entries(labels)) lines.push(`${label}: ${data[key] || 'Not provided'}`);
   lines.push('', 'Consent: I agree COCOVANTA may use these business details to assess potential cooperation and contact me.');
   status.textContent = 'WhatsApp is opening with your supplier introduction. Review it and press Send to submit directly to COCOVANTA.';
   if (button) button.disabled = true;
   window.open('https://wa.me/6285736277955?text='+encodeURIComponent(lines.join('\n')), '_blank', 'noopener');
   window.setTimeout(() => { if (button) button.disabled = false; }, 1800);
 });
})();
