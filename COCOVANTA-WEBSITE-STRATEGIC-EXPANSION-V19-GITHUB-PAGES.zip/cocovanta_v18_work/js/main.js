/* COCOVANTA public-site interactions. Static GitHub Pages edition. */
(() => {
 const $ = (selector) => document.querySelector(selector);
 const menuButton = $('#mobile-menu-btn');
 const menu = $('#mobile-menu');
 if (menuButton && menu) menuButton.addEventListener('click', () => {
   const open = menuButton.getAttribute('aria-expanded') !== 'true';
   menuButton.setAttribute('aria-expanded', String(open));
   menu.classList.toggle('hidden', !open);
 });
 const params = new URLSearchParams(window.location.search);
 const productField = $('#rfq-product');
 const quantityField = $('#rfq-qty');
 if (productField && params.has('product')) {
   const wanted = params.get('product');
   const option = [...productField.options].find(o => o.value.toLowerCase() === wanted.toLowerCase() || o.text.toLowerCase() === wanted.toLowerCase());
   if (option) productField.value = option.value;
 }
 if (quantityField && params.has('quantity')) quantityField.value = (params.get('quantity') || '').slice(0,180);
 const rfq = $('#rfq-form');
 if (rfq) rfq.addEventListener('submit', event => {
   event.preventDefault();
   if (!rfq.reportValidity()) return;
   const val = id => ($('#'+id)?.value || '').trim();
   const data = {
     company: val('rfq-company'), contact: val('rfq-name'), email: val('rfq-email'), country: val('rfq-country'),
     product: val('rfq-product'), quantity: val('rfq-qty'), destination: val('rfq-port') || 'To be discussed',
     incoterm: val('rfq-incoterm') || 'To be discussed', sample: val('rfq-sample'), docs: val('rfq-docs'),
     timing: val('rfq-timing') || 'Not specified', channel: val('rfq-contact-channel') || 'Email', requirements: val('rfq-message') || 'None'
   };
   const message = ['COCOVANTA — REQUEST FOR QUOTATION','',`Company: ${data.company}`,`Contact: ${data.contact}`,`Business email: ${data.email}`,`Country: ${data.country}`,`Product: ${data.product}`,`Quantity: ${data.quantity}`,`Destination port: ${data.destination}`,`Preferred Incoterm: ${data.incoterm}`,`Sample: ${data.sample}`,`Documents/evidence: ${data.docs}`,`Target shipment: ${data.timing}`,`Preferred reply channel: ${data.channel}`,`Additional requirements: ${data.requirements}`].join('\n');
   const status = $('#rfq-status');
   if (status) status.textContent = 'WhatsApp is opening with your prepared request. Review the details and press Send in WhatsApp to submit it.';
   window.open('https://wa.me/6285736277955?text='+encodeURIComponent(message), '_blank', 'noopener');
 });
 const heroVideo = $('video[autoplay]');
 if (heroVideo && window.matchMedia('(max-width: 640px)').matches) { heroVideo.pause(); heroVideo.removeAttribute('autoplay'); }
})();
