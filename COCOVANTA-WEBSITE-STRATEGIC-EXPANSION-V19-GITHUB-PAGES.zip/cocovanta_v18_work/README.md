# COCOVANTA — Indonesian Commodity Trader & Exporter

Release V19 · GitHub Pages static website

## Scope
This public website is exclusively for COCOVANTA's Indonesian commodity trading and export business. It presents commodities, buyer information, quality and export processes, company profile, buyer care, and a private supplier-introduction channel. It is not a marketplace, public supplier directory, hosting service, or technology company website.

## Publish with GitHub Pages
1. Create or open the GitHub repository intended for the public website.
2. Upload the **contents** of this ZIP to the repository root (not the ZIP file itself).
3. Confirm `index.html`, `assets/`, `css/`, `js/`, `products/`, `robots.txt`, `sitemap.xml`, `.nojekyll`, and `CNAME` are at the repository root.
4. In repository Settings → Pages, choose **Deploy from a branch**, select the production branch (usually `main`) and folder `/ (root)`, then save.
5. Add `cocovanta.web.id` as the custom domain in Pages settings. GitHub will show the DNS records required for the domain. Follow the values displayed by GitHub; do not guess or mix records from another host.
6. Enable HTTPS after GitHub verifies the domain and provisions the certificate.
7. Test the homepage, all product pages, mobile navigation, contact form and supplier introduction on the live domain.

## Important form behavior
GitHub Pages serves static files and does not run a private database or server-side form processor. The RFQ and supplier forms therefore prepare a WhatsApp message in the visitor's browser. Nothing is transmitted until the visitor reviews the message and presses **Send** in WhatsApp. The site does not claim that an enquiry has been received before that action. For automatic lead storage, notifications, spam controls and a private dashboard, connect a separately hosted backend in a later phase. Never put API secrets in this repository or frontend JavaScript.

## Before publishing
- Confirm product availability, specifications, packaging, MOQ, export capability and all commercial claims.
- Confirm that every image is authorised and correctly labelled.
- Check the founder profile, contact details and privacy notice.
- Run a live test from a second device and verify that the WhatsApp message is correctly prefilled.
- Review legal and destination-country requirements with a qualified adviser.

## Included
- Responsive export-focused public website and product pages.
- Buyer guide, buyer care, quality, export process, product intelligence and payment terms information.
- Clear proposed payment schedule: 50% advance after PI/contract acceptance and 50% balance before shipment, subject to the final written transaction documents.
- Buyer assistant (rule-based guidance; not a live AI or live inventory system).
- RFQ and supplier-introduction WhatsApp handoff.
- SEO metadata, sitemap, robots file, favicon and brand assets.

## Not included / not claimed
- No server-side database, CRM, automatic notifications, order processing or buyer portal.
- No automatic form receipt or confirmed quotation.
- No public supplier directory or direct buyer-to-supplier connection.
- No hosting/VPS sales content.

## V19 commercial payment explanation
The public payment terms page explains the standard proposed schedule of 50% advance and 50% balance before shipment. The final PI or signed sales contract controls each transaction, including currency, bank fees, due milestones, inspection terms and any approved exception. This is an explanatory website page, not a payment instruction.
